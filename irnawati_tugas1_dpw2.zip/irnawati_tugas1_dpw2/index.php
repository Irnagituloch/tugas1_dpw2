<?php

include "Animal.php";


class animal {
    public $jumlah_kaki, $bisa_terbang;
}

class Ayam extends animal 
{
    function bersuara ()
    {
        return "Mengkuruyuk (Kukuruyukkkk)";
    }
}

class Bebek extends animal 
{
    function bersuara ()
    {
        return "Menguik (kwek kwek)";
    }
}

class kambing extends animal 
{
    function bersuara ()
    {
        return "Mengembek (embekkk..)";
    }
}

class Nyamuk extends animal 
{
    function bersuara ()
    {
        return "Berdenging (nging..nging..nging..)";
    }
}

// Ayam
$Wiko = new Ayam;
$Wiko->jumlah_kaki = 2;
$Wiko->bisa_terbang = "Tidak Bisa Terbang";

echo "Wiko Adalah Ayam <br>";
echo "Punya Kaki Sebanyak: " . $Wiko->jumlah_kaki . "<br>";
echo $Wiko->bisa_terbang . "<br>";
echo "Suaranya: " . $Wiko->bersuara() . "<br>";


echo "<hr>";

// Bebek
$Wini = new Bebek;
$Wini->jumlah_kaki = 2;
$Wini->bisa_terbang = "Tidak Bisa Terbang";

echo "Wini Adalah Bebek <br>";
echo "Punya Kaki Sebanyak: " . $Wini->jumlah_kaki . "<br>";
echo $Wini->bisa_terbang . "<br>";
echo "Suaranya: " . $Wini->bersuara() . "<br>";

echo "<hr>";

// Kambing
$Wobi = new Kambing;
$Wobi->jumlah_kaki = 4;
$Wobi->bisa_terbang = "Tidak Bisa Terbang";

echo "Wobi Adalah Kambing <br>";
echo "Punya Kaki Sebanyak: " . $Wobi->jumlah_kaki . "<br>";
echo $Wobi->bisa_terbang . "<br>";
echo "Suaranya: " . $Wobi->bersuara() . "<br>";

echo "<hr>";

// Nyamuk
$Wisky = new Nyamuk;
$Wisky->jumlah_kaki = 6;
$Wisky->bisa_terbang = "Bisa Terbang";

echo "Wisky Adalah Nyamuk <br>";
echo "Punya Kaki Sebanyak: " . $Wisky->jumlah_kaki . "<br>";
echo $Wisky->bisa_terbang . "<br>";
echo "Suaranya: " . $Wisky->bersuara() . "<br>";

echo "<hr>";